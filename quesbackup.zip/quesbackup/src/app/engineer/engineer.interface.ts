export class EngineerInterface {
  

    public Name: string;
    public Age: Number;
    public DOB: string;
    public Gender: string;
    public AnnualIncome: string;
    
}