import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  ProfesionValue;
  constructor( private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
  }
  routeToForm(){
   if(this.ProfesionValue==1){
    this.router.navigateByUrl('/doctor');

   }
   else if(this.ProfesionValue==2){
    this.router.navigateByUrl('/engineer');

  }
  }
 
}
