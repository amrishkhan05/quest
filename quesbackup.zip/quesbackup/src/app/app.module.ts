import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { DoctorComponent } from './doctor/doctor.component';
import { EngineerComponent } from './engineer/engineer.component';
import { HomeComponent } from './home/home.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NetWorkingService } from './shared/networking.service';
import { Http, HttpModule } from '@angular/http';


const appRoutes: Routes = [
  {
    path : '', redirectTo : 'HomeComponent', pathMatch : 'full'
  },
  {
    path : '', component : HomeComponent
  },
  {
    path : 'doctor', component : DoctorComponent
  },
  {
    path : 'engineer', component : EngineerComponent
  }]
  
@NgModule({
  declarations: [
    AppComponent,
    DoctorComponent,
    EngineerComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    RouterModule.forRoot(
      appRoutes  , { useHash : true }
    ),
  ],
  providers: [NetWorkingService],
  bootstrap: [AppComponent]
})
export class AppModule { }
