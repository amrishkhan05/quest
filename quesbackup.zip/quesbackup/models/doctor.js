
const mongoose= require('mongoose');

const doctorQuestionSchema =mongoose.Schema({
     Name: { type : String, required: true },
    Age:{ type : Number,required : true},
    DOB:{ type : String,required : true},    
    Gender:{ type : String,required : true},
    AnnualIncome:{ type : String,required : true}
    
    
})

const Doctor=module.exports=mongoose.model('Doctor',doctorQuestionSchema);