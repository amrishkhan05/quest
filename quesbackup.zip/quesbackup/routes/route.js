const express = require('express');
const router = express.Router();
require('dotenv').config();
const Doctor = require('../models/doctor');
const Engineer=require('../models/engineer')

router.post('/doctor', (req, res, next) => {
    console.log(req.body)
    let newForm = new Doctor({
        Name: req.body.Name,
        Age:req.body.Age,
        DOB:req.body.DOB,
        Gender:req.body.Gender,
        AnnualIncome:req.body.AnnualIncome
})
newForm.save((err ) => {
    if (err) {
        return res.send();
        // console.log("err")
        //res.json({msg:'failed to add form'});
    } else {
       
        res.json(newForm);
    }
})
});
router.post('/Engineer', (req, res, next) => {
    console.log(req.body)
    let newForm = new Engineer({
        Name: req.body.Name,
        Age:req.body.Age,
        DOB:req.body.DOB,
        Gender:req.body.Gender,
        AnnualIncome:req.body.AnnualIncome
})
newForm.save((err) => {
    if (err) {
        return res.send();
        // console.log("err")
        //res.json({msg:'failed to add form'});
    } else {
       
        res.json(newForm);
    }
})
});
module.exports = router;